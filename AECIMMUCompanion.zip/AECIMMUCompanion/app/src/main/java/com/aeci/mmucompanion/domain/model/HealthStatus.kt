package com.aeci.mmucompanion.domain.model

enum class HealthStatus {
    HEALTHY,
    WARNING,
    ERROR,
    UNKNOWN
}
