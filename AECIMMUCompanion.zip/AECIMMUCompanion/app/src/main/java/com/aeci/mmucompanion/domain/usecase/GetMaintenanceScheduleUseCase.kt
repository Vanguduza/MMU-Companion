package com.aeci.mmucompanion.domain.usecase

import javax.inject.Inject

class GetMaintenanceScheduleUseCase @Inject constructor() {
    suspend operator fun invoke(): List<Any> {
        // TODO: Implement maintenance schedule retrieval
        return emptyList()
    }
}
